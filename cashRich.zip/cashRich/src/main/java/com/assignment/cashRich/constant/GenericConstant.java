package com.assignment.cashRich.constant;

public class GenericConstant {

    public static final String STATUS_FAILURE = "failure";
    public static final String STATUS_SUCCESS = "Success";
    public static final String APPLICATION = "application";
    public static final String CHANNEL = "channel";
}
