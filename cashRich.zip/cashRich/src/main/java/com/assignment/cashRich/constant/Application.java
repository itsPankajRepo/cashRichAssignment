package com.assignment.cashRich.constant;

public enum Application {
    CASH_RICH
}
