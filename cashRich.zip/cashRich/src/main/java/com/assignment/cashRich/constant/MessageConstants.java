package com.assignment.cashRich.constant;

public class MessageConstants {

    public static final String USER_CREATED_SUCCESSFULLY  = "User created successfully";

    public static final String LOGIN_SUCCESSFULLY  = "Login successfully";

    public static final String USER_UPDATED_SUCCESSFULLY  = "User updated successfully";

    public static final String NOT_ABLE_TO_MODIFY_USER = "Not able to modfiy user ";

    public static final String SOMETHING_WENT_WRONG = "Something went wrong";

    public static final String  FETCHED_DATA_SUCCESSFULLY = "Fetch data successfully";
    public static final String  NO_DATA_FOUND = "No data found";

}
