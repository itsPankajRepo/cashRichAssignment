package com.assignment.cashRich.constant;

public enum Channel {
    APP,WEB_PORTAL
}
